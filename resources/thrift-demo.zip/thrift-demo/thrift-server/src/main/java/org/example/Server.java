package org.example;

import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TSimpleServer;
import org.apache.thrift.transport.TServerSocket;
import org.apache.thrift.transport.TServerTransport;
import org.apache.thrift.transport.TTransportException;
import org.example.service.UserServiceImpl;

public class Server {
    public static void main(String[] args) {
        try {
            TServerTransport serverTransport = new TServerSocket(9090);
            TBinaryProtocol.Factory protocolFactory = new TBinaryProtocol.Factory();
            UserService.Processor<UserServiceImpl> processor = new UserService.Processor<>(new UserServiceImpl());

            TSimpleServer.Args targs = new TSimpleServer.Args(serverTransport);
            targs.protocolFactory(protocolFactory);
            targs.processor(processor);

            // Simple single-threaded server for testing
            TServer server = new TSimpleServer(targs);
            System.out.println("Starting the TSimpleServer server.");
            server.serve();
        } catch (TTransportException e) {
            throw new RuntimeException(e);
        }
    }
}