package org.example.service;

import org.apache.thrift.TException;
import org.example.User;
import org.example.UserService;

import java.util.concurrent.ConcurrentHashMap;

public class UserServiceImpl implements UserService.Iface {
    private final ConcurrentHashMap<Integer, User> table = new ConcurrentHashMap<>();

    @Override
    public boolean addUser(User user) throws TException {
        System.out.println("method addUser is called");
        boolean result = !table.containsKey(user.getId());
        table.put(user.getId(), user);
        return result;
    }

    @Override
    public boolean containsUser(int id) throws TException {
        System.out.println("method containsUser is called");
        return table.containsKey(id);
    }

    @Override
    public User getUserById(int id) throws TException {
        System.out.println("method getUserById is called");
        return table.get(id);
    }
}
