namespace java org.example

struct User {
	1:i32 id,
	2:string name
}

service UserService {
	bool addUser(1:User user),
	bool containsUser(1:i32 id),
	User getUserById(1:i32 id)
}