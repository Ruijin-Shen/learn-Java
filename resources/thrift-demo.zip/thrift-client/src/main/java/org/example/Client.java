package org.example;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;

public class Client {
    public static void main(String[] args) {
        TTransport transport = null;
        try {
            transport = new TSocket("localhost", 9090);
            TProtocol protocol = new TBinaryProtocol(transport);
            UserService.Client client = new UserService.Client(protocol);

            transport.open();
            // remote procedure call
            User alice = new User(1, "Alice");
            boolean isSuccess = false;
            isSuccess = client.addUser(alice);
            System.out.println("Insterting " + alice.toString() +  (isSuccess ? " succeeds" : " failed"));

            isSuccess = client.addUser(alice);
            System.out.println("Insterting " + alice.toString() +  (isSuccess ? " succeeds" : " failed"));

            System.out.println("User " + alice.toString() + (client.containsUser(alice.getId()) ? " exists" : " does not exists"));
            User bob = new User(2, "Bob");
            System.out.println("User " + bob.toString() + (client.containsUser(bob.getId()) ? " exists" : " does not exist"));

            User result = client.getUserById(1);
            System.out.println("User with id 1: " + result);
        } catch (TTransportException e) {
            throw new RuntimeException(e);
        } catch (TException e) {
            throw new RuntimeException(e);
        } finally {
            if (transport != null) transport.close();
        }
    }
}
